# UCAS 课程选择模拟器

中国科学院大学（UCAS）研究生选课模拟器。基于 **PySide6** 的桌面应用，支持教务系统课表一键导入、多维筛选、周视图课表、时间冲突检测与多格式导出。

## 功能特性

- **课表导入**：直接导入教务系统导出的 xlsx 课表，自动解析课程与时间安排（含合并单元格结构），生成内置 SQLite 数据库
- **多维筛选**：课程名称/代码关键词 + 院系、培养层次、校区、开课单位、学科门类/归属/专业领域三级联动筛选（基于 18 位课程编号规则与《研究生教育学科专业目录（2022年）》）
- **周视图课表**：13 节 × 7 天网格，周次导航（1–20 周），时间冲突红色高亮，同格冲突课程并列显示
- **选课管理**：双击选课/退课，冲突弹窗确认，学分/课程数/冲突数实时统计
- **多格式导出**：课程明细列表或逐周课表（每周一张网格），均支持 CSV / Excel / PDF / JSON
- **状态缓存**：自动记住导入的数据源、已选课程、窗口尺寸、分栏比例、当前周次与筛选条件，重启后完整恢复

## 快速开始

环境要求：Python ≥ 3.12，使用 [uv](https://docs.astral.sh/uv/) 管理依赖。

```bash
git clone <repo-url>
cd CourseSystem
uv sync
uv run coursesystem
```

首次运行后，点击「导入课表」选择教务系统导出的 xlsx 文件（示例见 `data/2026年秋季学期课表.xlsx`），解析后的 SQLite 库保存在 `data/` 下并被自动记住。

## 打包分发

使用 PyInstaller 构建绿色便携版（onedir）：

```bash
uv sync                       # 含 dev 依赖 pyinstaller
uv run pyinstaller coursesystem.spec --noconfirm
```

产物为 `dist/UCAS课程选择模拟器/` 文件夹，整体压缩为 zip 即可分发；用户解压后双击 `UCAS课程选择模拟器.exe` 运行，无需安装 Python。应用内首次启动会引导导入课表 xlsx；状态缓存与导入生成的课程库保存在 exe 同级 `data/` 目录，随文件夹整体迁移不丢失。

## 课程编号规则

课程编码共 18 位，应用据此提供筛选维度（详见 `data/课程编号内容.png`）：

| 位 | 含义 | 示例 |
|---|---|---|
| 1 | 开课单位 | 1 京内学院 / 2 京外学院 / 3 教育基地 / 4 研究所 |
| 2–6 | 单位/院系代码 | |
| 7–12 | 学科代码 | 085406 控制工程 → 归属 0854 电子信息 → 门类 08 工学 |
| 13 | 培养层次 | M 硕士 / D 博士 / P 硕博通用 |
| 15–17 | 顺序码 | |
| 18 | 校区 | H 雁栖湖 / Y 玉泉路 / Z 中关村 |

节次时刻表采用《中国科学院大学课程节次调整方案》（13 节，每节 45 分钟，见 `data/时间表.jpg`）。

## 项目结构

```
├── pyproject.toml           # 项目与依赖定义（uv）
├── src/coursesystem/        # 应用主包
│   ├── __init__.py          # 入口 main()（uv run coursesystem）
│   ├── config.py            # 常量：节次时刻表、星期、导出格式
│   ├── models.py            # Course / Schedule 数据模型
│   ├── code.py              # 课程编码位解析（单位/层次/校区）
│   ├── disciplines.py       # 学科门类/一级学科/专业领域映射表
│   ├── conflict.py          # 节次/周次解析与冲突检测
│   ├── db.py                # SQLite 数据访问层（筛选查询）
│   ├── importer/            # 教务 xlsx 解析与写库
│   ├── exporter.py          # 明细/逐周课表 × CSV/Excel/PDF/JSON
│   ├── state.py             # 状态缓存（JSON 持久化）
│   ├── paths.py             # 运行时路径（开发态/冻结态统一）
│   ├── week_view.py         # 周视图组件
│   ├── statistics.py        # 统计横条组件
│   └── main_window.py       # 主窗口（布局、筛选、选课、导入导出）
├── launcher.py              # PyInstaller 打包入口
├── coursesystem.spec        # PyInstaller 构建配置
├── data/                    # 示例课表与编号规则图（生成的 .db 与缓存不入库）
└── LICENSE                  # MIT
```

## 技术栈

- GUI：PySide6（Qt6）
- 存储：SQLite（标准库 sqlite3）
- 导出：pandas + openpyxl（Excel）、reportlab（PDF，内嵌中文字体）、csv/json（标准库）

## 致谢

本项目参考了开源项目 ucas_course_select_monitor（UCAS 课程选择模拟器，PyQt5 版）的思路与数据结构，并修复了其周次匹配、星期显示、PDF 中文乱码等已知问题；在 PySide6 下完全重写并扩展了导入、三级学科筛选、逐周导出与状态缓存等功能。

## 许可证

[MIT](LICENSE)
