"""支持 python -m coursesystem 启动"""

from . import main

if __name__ == "__main__":
    main()
