"""全局配置常量"""

import os
from pathlib import Path

from .paths import data_dir

# 默认课程库：数据目录下的 courses.db，可用环境变量覆盖
_DEFAULT_DB = data_dir() / "courses.db"
DATABASE_PATH = Path(os.environ.get("COURSESYSTEM_DB", _DEFAULT_DB))

APP_NAME = "UCAS课程选择模拟器"
APP_VERSION = "3.1.0"

WINDOW_WIDTH = 1600
WINDOW_HEIGHT = 950

# 节次时刻表（中国科学院大学课程节次调整方案，共 13 节，每节 45 分钟）
TIME_SLOTS = {
    1: "08:30-09:15", 2: "09:20-10:05", 3: "10:25-11:10", 4: "11:15-12:00",
    5: "13:30-14:15", 6: "14:20-15:05", 7: "15:25-16:10", 8: "16:15-17:00",
    9: "17:05-17:50",  # 机动
    10: "18:30-19:15", 11: "19:20-20:05", 12: "20:15-21:00", 13: "21:05-21:50",
}
MIN_SLOT = min(TIME_SLOTS)
MAX_SLOT = max(TIME_SLOTS)

WEEKDAYS = {
    1: "周一", 2: "周二", 3: "周三", 4: "周四",
    5: "周五", 6: "周六", 7: "周日",
}

MIN_WEEK = 1
MAX_WEEK = 20

SUPPORTED_EXPORT_FORMATS = {
    "csv": "CSV文件 (*.csv)",
    "xlsx": "Excel文件 (*.xlsx)",
    "pdf": "PDF文件 (*.pdf)",
    "json": "JSON文件 (*.json)",
}
