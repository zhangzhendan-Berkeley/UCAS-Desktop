"""课程编码解析

18 位编码规则（中国科学院大学研究生课程编号）：
  第1位    开课单位：1京内学院 2京外学院 3教育基地 4研究所
  第2-6位  单位/院系代码
  第7-12位 学科代码
  第13位   培养层次：M硕士 D博士 P硕博通用
  第14位   课程属性
  第15-17位 顺序码
  第18位   校区：H雁栖湖 Y玉泉路 Z中关村
"""

UNIT_TYPES = {"1": "京内学院", "2": "京外学院", "3": "教育基地", "4": "研究所"}
LEVELS = {"M": "硕士课程", "D": "博士课程", "P": "硕博通用"}
CAMPUSES = {"H": "雁栖湖校区", "Y": "玉泉路校区", "Z": "中关村校区"}


def parse_course_code(code: str) -> dict:
    """解析课程编码，长度不足时对应字段为 None"""
    code = code or ""
    return {
        "unit": UNIT_TYPES.get(code[0]) if len(code) >= 1 else None,
        "level": LEVELS.get(code[12]) if len(code) >= 13 else None,
        "campus": CAMPUSES.get(code[17]) if len(code) >= 18 else None,
    }
