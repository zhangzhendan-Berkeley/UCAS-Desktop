"""主窗口：左搜索/中周视图/右已选与统计"""

import logging
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QFileDialog, QGridLayout, QGroupBox, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMessageBox,
    QPushButton, QSizePolicy, QSplitter, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from .conflict import check_conflict
from .config import APP_NAME, APP_VERSION, SUPPORTED_EXPORT_FORMATS, WINDOW_HEIGHT, WINDOW_WIDTH
from .db import CourseDatabase
from .exporter import ScheduleExporter
from .models import Course
from .paths import data_dir
from .statistics import StatisticsWidget
from .week_view import WeekViewWidget

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self, db: CourseDatabase | None = None):
        super().__init__()
        self.db = db or self._restore_db()
        self.exporter = ScheduleExporter()
        self.selected: dict[int, Course] = {}  # course_id -> Course（含 schedules）

        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(WINDOW_WIDTH, WINDOW_HEIGHT)

        self._init_ui()
        self._load_courses()
        self._restore_selection()
        self._restore_ui()

    # ---------- 状态缓存 ----------

    @staticmethod
    def _restore_db() -> CourseDatabase:
        """启动时恢复上次使用的数据源（如导入的课表库），失效则回退默认"""
        from .state import load_state

        db_path = load_state().get("db_path")
        if db_path and Path(db_path).exists():
            logger.info("恢复上次的数据源：%s", db_path)
            return CourseDatabase(Path(db_path))
        return CourseDatabase()

    def _restore_selection(self):
        """启动时恢复上次的已选课程（当前库中不存在的 id 自动跳过）"""
        from .state import load_state

        ids = load_state().get("selected_course_ids", [])
        if not ids:
            self._refresh_views()  # 显示空列表占位提示
            return
        courses = self.db.get_courses_with_schedules(ids)
        self.selected = {c.id: c for c in courses}
        if len(self.selected) < len(ids):
            logger.info("有 %d 门已选课程在当前库中不存在，已跳过",
                        len(ids) - len(self.selected))
        self._refresh_views()

    def _save_state(self):
        from .state import save_state

        save_state(db_path=self.db.db_path,
                   selected_course_ids=list(self.selected.keys()))

    # ---------- 界面状态缓存 ----------

    def _collect_ui_state(self) -> dict:
        return {
            "geometry": bytes(self.saveGeometry().toBase64()).decode(),
            "splitter_sizes": self.splitter.sizes(),
            "week": self.week_view.current_week(),
            "filter_panel_expanded": self.filter_toggle.isChecked(),
            "keyword": self.search_input.text(),
            "filters": {
                "department": self.dept_combo.currentData(),
                "level": self.level_combo.currentData(),
                "campus": self.campus_combo.currentData(),
                "unit": self.unit_combo.currentData(),
                "menlei": self.menlei_combo.currentData(),
                "category": self.category_combo.currentData(),
                "field": self.field_combo.currentData(),
                "attribute": self.attr_combo.currentData(),
            },
        }

    def _restore_ui(self):
        """恢复上次的界面状态（在筛选下拉填充完毕后调用）"""
        from PySide6.QtCore import QTimer
        from .state import load_state

        ui = load_state().get("ui") or {}
        if not ui:
            return

        # 窗口几何与分栏比例需在窗口完成布局后应用，延迟到事件循环
        self._pending_geometry = ui.get("geometry")
        self._pending_sizes = ui.get("splitter_sizes")
        QTimer.singleShot(0, self._apply_pending_geometry)

        week = ui.get("week")
        if isinstance(week, int):
            self.week_view.week_spin.setValue(week)

        self.filter_toggle.setChecked(bool(ui.get("filter_panel_expanded")))

        keyword = ui.get("keyword", "")
        if keyword:
            self.search_input.blockSignals(True)
            self.search_input.setText(keyword)
            self.search_input.blockSignals(False)

        # 下拉按数据值恢复；三级联动需按 门类→归属→领域 顺序重建
        filters = ui.get("filters") or {}

        def set_combo(combo: QComboBox, value) -> bool:
            if value is None:
                return False
            idx = combo.findData(value)
            if idx < 0:
                return False  # 当前库中不存在该选项，保持"全部"
            combo.blockSignals(True)
            combo.setCurrentIndex(idx)
            combo.blockSignals(False)
            return True

        set_combo(self.dept_combo, filters.get("department"))
        set_combo(self.level_combo, filters.get("level"))
        set_combo(self.campus_combo, filters.get("campus"))
        set_combo(self.unit_combo, filters.get("unit"))
        if set_combo(self.menlei_combo, filters.get("menlei")):
            self._rebuild_category_combo()
        if set_combo(self.category_combo, filters.get("category")):
            self._rebuild_field_combo()
        set_combo(self.field_combo, filters.get("field"))
        set_combo(self.attr_combo, filters.get("attribute"))
        self._apply_filters()

    def _apply_pending_geometry(self):
        """窗口显示后应用缓存的几何与分栏比例"""
        from PySide6.QtCore import QByteArray

        if self._pending_geometry:
            self.restoreGeometry(QByteArray.fromBase64(
                self._pending_geometry.encode()))
            self._pending_geometry = None
        sizes = self._pending_sizes
        self._pending_sizes = None
        if sizes and len(sizes) == 3 and all(isinstance(s, int) and s > 0 for s in sizes):
            total = sum(sizes)
            width = max(self.splitter.width(), 1)
            # 按当前宽度等比缩放恢复（Qt 会自动夹紧到各栏最小宽度）
            self.splitter.setSizes([round(s * width / total) for s in sizes])
            # 后续窗口缩放时按相同比例分配空间
            for i, size in enumerate(sizes):
                self.splitter.setStretchFactor(i, size)

    def closeEvent(self, event):
        self._save_state()
        from .state import save_state
        save_state(ui=self._collect_ui_state())
        super().closeEvent(event)

    # ---------- UI ----------

    _QSS = """
        QMainWindow, QWidget { background: #f5f6f8; font-size: 13px; }
        QGroupBox {
            font-weight: bold; border: 1px solid #e1e4e8; border-radius: 8px;
            margin-top: 12px; padding-top: 14px; background-color: white;
        }
        QGroupBox::title {
            subcontrol-origin: margin; left: 10px; padding: 0 6px; color: #24292e;
        }
        QPushButton {
            background: white; border: 1px solid #d1d5db; border-radius: 5px;
            padding: 6px 14px; color: #24292e;
        }
        QPushButton:hover { border-color: #0366d6; color: #0366d6; }
        QPushButton#primary {
            background: #0366d6; color: white; border: none; font-weight: bold;
        }
        QPushButton#primary:hover { background: #0472e6; }
        QLineEdit, QComboBox, QSpinBox {
            padding: 5px 8px; border: 1px solid #d1d5db; border-radius: 5px;
            background: white;
        }
        QLineEdit:focus, QComboBox:focus { border-color: #0366d6; }
        QSpinBox::up-button, QSpinBox::down-button {
            width: 16px; border: none; background: transparent;
        }
        QSpinBox::up-arrow {
            width: 7px; height: 7px;
            border-left: 4px solid transparent; border-right: 4px solid transparent;
            border-bottom: 5px solid #6b7280;
        }
        QSpinBox::down-arrow {
            width: 7px; height: 7px;
            border-left: 4px solid transparent; border-right: 4px solid transparent;
            border-top: 5px solid #6b7280;
        }
        QTableWidget, QListWidget {
            background: white; border: 1px solid #e1e4e8; border-radius: 6px;
            gridline-color: #eef0f2;
        }
        QHeaderView::section {
            background: #f6f8fa; border: none; border-bottom: 1px solid #e1e4e8;
            padding: 6px; font-weight: bold;
        }
        QToolButton#filterToggle {
            border: none; color: #0366d6; font-weight: normal; padding: 2px 4px;
        }
        QFrame#statsBar {
            background: white; border: 1px solid #e1e4e8; border-radius: 6px;
        }
    """

    def _init_ui(self):
        self.setStyleSheet(self._QSS)
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # ---- 左栏：搜索 + 可折叠高级筛选 + 课程列表 ----
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(6, 6, 6, 6)
        search_box = QGroupBox("课程筛选")
        search_layout = QVBoxLayout(search_box)
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("输入课程名称或课程代码，回车或点击搜索…")
        self.search_input.setClearButtonEnabled(True)
        btn_row = QHBoxLayout()
        self.search_btn = QPushButton("搜索")
        self.search_btn.setObjectName("primary")
        self.clear_btn = QPushButton("清空")
        btn_row.addWidget(self.search_btn)
        btn_row.addWidget(self.clear_btn)
        search_layout.addWidget(self.search_input)
        search_layout.addLayout(btn_row)

        # 可折叠的高级筛选面板（默认收起）
        from PySide6.QtWidgets import QToolButton

        self.filter_toggle = QToolButton()
        self.filter_toggle.setObjectName("filterToggle")
        self.filter_toggle.setText("高级筛选")
        self.filter_toggle.setCheckable(True)
        self.filter_toggle.setChecked(False)
        self.filter_toggle.setToolButtonStyle(
            Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.filter_toggle.setArrowType(Qt.ArrowType.RightArrow)
        search_layout.addWidget(self.filter_toggle)

        from .code import CAMPUSES, LEVELS, UNIT_TYPES
        from .disciplines import MENLEI

        def make_combo(items: dict[str, str]) -> QComboBox:
            combo = QComboBox()
            combo.addItem("全部", None)
            for value, label in items.items():
                combo.addItem(label, value)
            return combo

        self.dept_combo = QComboBox()
        self.dept_combo.addItem("全部院系", None)
        self.level_combo = make_combo(LEVELS)
        self.campus_combo = make_combo(CAMPUSES)
        self.unit_combo = make_combo(UNIT_TYPES)
        self.menlei_combo = make_combo(MENLEI)
        self.category_combo = QComboBox()
        self.category_combo.addItem("全部归属", None)
        self.field_combo = QComboBox()
        self.field_combo.addItem("全部领域", None)
        self.attr_combo = QComboBox()
        self.attr_combo.addItem("全部属性", None)

        self.filter_panel = QWidget()
        # 两列网格：标签列右对齐且等宽、下拉列等宽拉伸，避免行列错位
        grid = QGridLayout(self.filter_panel)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)

        self._filter_labels: dict[QComboBox, QLabel] = {}

        def _field(row: int, col: int, label_text: str, combo: QComboBox) -> None:
            label = QLabel(label_text)
            label.setAlignment(
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            grid.addWidget(label, row, col * 2)
            grid.addWidget(combo, row, col * 2 + 1)
            self._filter_labels[combo] = label

        _field(0, 0, "院系", self.dept_combo)
        _field(0, 1, "层次", self.level_combo)
        _field(1, 0, "校区", self.campus_combo)
        _field(1, 1, "单位", self.unit_combo)
        _field(2, 0, "门类", self.menlei_combo)
        _field(2, 1, "归属", self.category_combo)
        _field(3, 0, "领域", self.field_combo)
        _field(3, 1, "属性", self.attr_combo)

        for combo in self._filter_labels:
            # 限制最小宽度并允许收缩，保证两列下拉等宽对齐
            combo.setSizeAdjustPolicy(
                QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.setMinimumContentsLength(6)
            combo.setSizePolicy(
                QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self.filter_panel.setVisible(False)
        search_layout.addWidget(self.filter_panel)
        left_layout.addWidget(search_box, stretch=0)

        self.course_table = QTableWidget(0, 4)
        self.course_table.setHorizontalHeaderLabels(["课程代码", "课程名称", "学分", "学时"])
        header = self.course_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        self.course_table.setColumnWidth(0, 165)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        self.course_table.setColumnWidth(2, 50)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.course_table.setColumnWidth(3, 50)
        self.course_table.verticalHeader().setDefaultSectionSize(28)
        self.course_table.verticalHeader().setVisible(False)
        self.course_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.course_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        left_layout.addWidget(self.course_table, stretch=1)
        self.result_count_label = QLabel("共 0 门课程，双击添加")
        self.result_count_label.setStyleSheet("color: #6b7280; font-size: 12px;")
        left_layout.addWidget(self.result_count_label, stretch=0)

        # ---- 中栏：操作 + 周视图（视觉焦点） ----
        middle = QWidget()
        middle_layout = QVBoxLayout(middle)
        middle_layout.setContentsMargins(6, 6, 6, 6)
        toolbar = QHBoxLayout()
        self.import_btn = QPushButton("导入课表")
        self.export_btn = QPushButton("导出课程表")
        self.export_btn.setObjectName("primary")
        toolbar.addWidget(self.import_btn)
        toolbar.addWidget(self.export_btn)
        toolbar.addStretch()
        middle_layout.addLayout(toolbar)
        self.week_view = WeekViewWidget()
        middle_layout.addWidget(self.week_view, stretch=1)

        # ---- 右栏：统计横条 + 已选课程 ----
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(6, 6, 6, 6)
        self.stats = StatisticsWidget()
        right_layout.addWidget(self.stats, stretch=0)
        selected_box = QGroupBox("已选课程")
        selected_layout = QVBoxLayout(selected_box)
        self.selected_list = QListWidget()
        remove_row = QHBoxLayout()
        self.remove_btn = QPushButton("移除选中")
        self.clear_all_btn = QPushButton("清空")
        remove_row.addWidget(self.remove_btn)
        remove_row.addWidget(self.clear_all_btn)
        selected_layout.addWidget(self.selected_list)
        selected_layout.addLayout(remove_row)
        right_layout.addWidget(selected_box, stretch=1)

        for widget, minimum in ((left, 360), (middle, 620), (right, 240)):
            widget.setMinimumWidth(minimum)
        splitter.addWidget(left)
        splitter.addWidget(middle)
        splitter.addWidget(right)
        splitter.setSizes([400, 1000, 280])
        self.splitter = splitter
        self.setCentralWidget(splitter)

        # 信号
        self.search_input.textChanged.connect(self._apply_filters)
        self.search_btn.clicked.connect(self._apply_filters)
        self.clear_btn.clicked.connect(self._on_clear_search)
        self.filter_toggle.toggled.connect(self._on_filter_toggled)
        for combo in (self.dept_combo, self.level_combo,
                      self.campus_combo, self.unit_combo,
                      self.field_combo, self.attr_combo):
            combo.currentIndexChanged.connect(self._apply_filters)
        self.menlei_combo.currentIndexChanged.connect(self._on_menlei_changed)
        self.category_combo.currentIndexChanged.connect(self._on_category_changed)
        self.course_table.doubleClicked.connect(self._add_current_course)
        self.selected_list.doubleClicked.connect(self._remove_current_course)
        self.remove_btn.clicked.connect(self._remove_current_course)
        self.clear_all_btn.clicked.connect(self._clear_all)
        self.import_btn.clicked.connect(self._import)
        self.export_btn.clicked.connect(self._export)
        # 周次切换即时缓存，防止异常退出丢失
        self.week_view.week_spin.valueChanged.connect(self._on_week_changed)

    def _on_week_changed(self, week: int):
        from .state import save_state
        save_state(ui={"week": week})

    def _on_filter_toggled(self, checked: bool):
        self.filter_panel.setVisible(checked)
        self.filter_toggle.setArrowType(
            Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)

    # ---------- 数据加载与筛选 ----------

    def _load_courses(self):
        """加载课程列表，并重建院系/学科归属下拉（切换数据源后调用）"""
        from .disciplines import CATEGORIES

        self.dept_combo.blockSignals(True)
        self.dept_combo.clear()
        self.dept_combo.addItem("全部院系", None)
        for dept in self.db.get_departments():
            self.dept_combo.addItem(dept, dept)
        self.dept_combo.blockSignals(False)

        self.attr_combo.blockSignals(True)
        self.attr_combo.clear()
        self.attr_combo.addItem("全部属性", None)
        for attr in self.db.get_attributes():
            self.attr_combo.addItem(attr, attr)
        self.attr_combo.blockSignals(False)

        # 旧库缺少对应列时隐藏该筛选项（标签随下拉一起隐藏）
        for combo, available in ((self.dept_combo, self.db.has_department),
                                 (self.attr_combo, self.db.has_attribute)):
            combo.setVisible(available)
            self._filter_labels[combo].setVisible(available)

        # 学科归属：只列出当前库中实际出现的类别
        self._db_categories = [
            (code, CATEGORIES.get(code, "其他"))
            for code in self.db.get_categories()
        ]
        self._rebuild_category_combo()
        self._apply_filters()

    def _rebuild_category_combo(self):
        """按当前选中的门类重建学科归属下拉"""
        menlei = self.menlei_combo.currentData()
        self.category_combo.blockSignals(True)
        self.category_combo.clear()
        self.category_combo.addItem("全部归属", None)
        for code, name in self._db_categories:
            if menlei is None or code.startswith(menlei):
                self.category_combo.addItem(f"{name}（{code}）", code)
        self.category_combo.blockSignals(False)
        self._rebuild_field_combo()

    def _rebuild_field_combo(self):
        """按当前选中的归属重建领域下拉

        领域列表 = 官方目录中该类别的全部领域 ∪ 库中实际出现的 6 位代码
        （自设码如 '0705Z1' 无官方名称，直接显示代码）。
        """
        from .disciplines import CATEGORIES, fields_of_category

        category = self.category_combo.currentData()
        self.field_combo.blockSignals(True)
        self.field_combo.clear()
        self.field_combo.addItem("全部领域", None)
        if category:
            entries: dict[str, str] = dict(fields_of_category(category))
            for code in self.db.get_fields(category):
                if code not in entries:
                    # xxXX00 与类别同名；自设码显示代码本身
                    entries[code] = (
                        CATEGORIES.get(code[:4], code)
                        if code.isdigit() and code.endswith("00") else code
                    )
            for code, name in sorted(entries.items()):
                self.field_combo.addItem(f"{name}（{code}）", code)
        self.field_combo.blockSignals(False)

    def _on_menlei_changed(self):
        self._rebuild_category_combo()
        self._apply_filters()

    def _on_category_changed(self):
        self._rebuild_field_combo()
        self._apply_filters()

    def _apply_filters(self):
        if not self.db.is_valid:
            self._show_empty_db_placeholder()
            return
        self._fill_table(self.db.search_courses(
            keyword=self.search_input.text().strip(),
            department=self.dept_combo.currentData(),
            level=self.level_combo.currentData(),
            campus=self.campus_combo.currentData(),
            unit=self.unit_combo.currentData(),
            menlei=self.menlei_combo.currentData(),
            category=self.category_combo.currentData(),
            field=self.field_combo.currentData(),
            attribute=self.attr_combo.currentData(),
        ))

    def _on_clear_search(self):
        self.search_input.clear()
        for combo in (self.dept_combo, self.level_combo,
                      self.campus_combo, self.unit_combo,
                      self.menlei_combo, self.category_combo,
                      self.field_combo, self.attr_combo):
            combo.blockSignals(True)
            combo.setCurrentIndex(0)
            combo.blockSignals(False)
        self._rebuild_category_combo()  # 门类重置后恢复完整的归属/领域列表
        self._apply_filters()

    def _fill_table(self, courses: list[Course]):
        self.course_table.setRowCount(len(courses))
        for row, c in enumerate(courses):
            for col, text in enumerate([c.code, c.name, c.credits, c.hours]):
                item = QTableWidgetItem(text)
                item.setToolTip(f"{c.name}\n{c.code}")
                if col == 0:
                    item.setData(Qt.ItemDataRole.UserRole, c.id)
                self.course_table.setItem(row, col, item)
        self.result_count_label.setText(f"共 {len(courses)} 门课程，双击添加")

    def _show_empty_db_placeholder(self):
        """无有效课程库时的空态：表格占位 + 引导导入"""
        self.course_table.setRowCount(1)
        item = QTableWidgetItem(
            "暂无课程数据，请点击上方「导入课表」选择教务系统导出的 xlsx 文件")
        item.setFlags(Qt.ItemFlag.NoItemFlags)
        self.course_table.setItem(0, 1, item)
        self.result_count_label.setText("未加载课程数据")

    # ---------- 选课 / 退课 ----------

    def _add_current_course(self):
        row = self.course_table.currentRow()
        if row < 0:
            return
        first_cell = self.course_table.item(row, 0)
        if first_cell is None:  # 空态占位行
            return
        course_id = first_cell.data(Qt.ItemDataRole.UserRole)
        if course_id in self.selected:
            QMessageBox.information(self, "提示", "该课程已在选课列表中")
            return

        course = self.db.get_courses_with_schedules([course_id])[0]
        conflicts = self._conflicts_with_selected(course)
        if conflicts:
            names = "、".join(sorted({c.name for c in conflicts}))
            answer = QMessageBox.question(
                self, "时间冲突",
                f"该课程与已选课程【{names}】存在时间冲突。\n是否仍要添加？")
            if answer != QMessageBox.StandardButton.Yes:
                return

        self.selected[course_id] = course
        self._refresh_views()

    def _remove_current_course(self):
        item = self.selected_list.currentItem()
        if not item:
            return
        course_id = item.data(Qt.ItemDataRole.UserRole)
        self.selected.pop(course_id, None)
        self._refresh_views()

    def _clear_all(self):
        if not self.selected:
            return
        answer = QMessageBox.question(self, "确认", "确定要清空所有已选课程吗？")
        if answer == QMessageBox.StandardButton.Yes:
            self.selected.clear()
            self._refresh_views()

    def _conflicts_with_selected(self, course: Course) -> list[Course]:
        result = []
        for existing in self.selected.values():
            if any(check_conflict(n, e)
                   for n in course.schedules for e in existing.schedules):
                result.append(existing)
        return result

    def _count_conflicts(self) -> int:
        """统计所有已选课程两两之间的冲突对数"""
        courses = list(self.selected.values())
        count = 0
        for i in range(len(courses)):
            for j in range(i + 1, len(courses)):
                if any(check_conflict(a, b)
                       for a in courses[i].schedules for b in courses[j].schedules):
                    count += 1
        return count

    def _refresh_views(self):
        courses = list(self.selected.values())
        self.selected_list.clear()
        for c in courses:
            item = QListWidgetItem(f"{c.name}（{c.code}）")
            item.setData(Qt.ItemDataRole.UserRole, c.id)
            self.selected_list.addItem(item)
        if not courses:  # 空列表占位提示
            placeholder = QListWidgetItem("暂无已选课程\n双击左侧课程列表中的课程添加")
            placeholder.setFlags(Qt.ItemFlag.NoItemFlags)
            placeholder.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.selected_list.addItem(placeholder)
        self.week_view.set_courses(courses)
        self.stats.update_stats(courses, self._count_conflicts())
        self._save_state()

    # ---------- 导入 ----------

    def _import(self):
        """导入教务系统导出的 xlsx 课表，生成 SQLite 并切换数据源"""
        from .importer import parse_xlsx, write_db

        xlsx_path, _ = QFileDialog.getOpenFileName(
            self, "选择课表文件", "", "Excel文件 (*.xlsx)")
        if not xlsx_path:
            return
        try:
            result = parse_xlsx(xlsx_path)
        except Exception as e:
            logger.exception("课表解析失败")
            QMessageBox.critical(self, "导入失败", f"课表解析失败：{e}")
            return
        if not result.courses:
            QMessageBox.warning(self, "导入失败", "未从文件中解析到任何课程")
            return

        data_dir().mkdir(parents=True, exist_ok=True)
        default_db = str(data_dir() / f"{Path(xlsx_path).stem}.db")
        db_path, _ = QFileDialog.getSaveFileName(
            self, "保存课程数据库", default_db, "SQLite数据库 (*.db)")
        if not db_path:
            return

        try:
            course_count, schedule_count = write_db(result, db_path)
        except Exception as e:
            logger.exception("数据库写入失败")
            QMessageBox.critical(self, "导入失败", f"数据库写入失败：{e}")
            return

        # 切换到新数据源并重载
        self.db = CourseDatabase(Path(db_path))
        self.selected.clear()
        self._load_courses()
        self._refresh_views()
        QMessageBox.information(
            self, "导入成功",
            f"已导入 {course_count} 门课程、{schedule_count} 条时间安排"
            f"（学期：{result.semester}），跳过 {result.skipped_rows} 行。")

    # ---------- 导出 ----------

    def _export(self):
        if not self.selected:
            QMessageBox.information(self, "提示", "请先选择课程再导出")
            return

        mode_box = QMessageBox(self)
        mode_box.setWindowTitle("导出课程表")
        mode_box.setText("请选择导出形式：")
        detail_btn = mode_box.addButton("课程明细列表", QMessageBox.ButtonRole.AcceptRole)
        weekly_btn = mode_box.addButton("逐周课表", QMessageBox.ButtonRole.AcceptRole)
        mode_box.addButton(QMessageBox.StandardButton.Cancel)
        mode_box.exec()
        clicked = mode_box.clickedButton()
        if clicked not in (detail_btn, weekly_btn):
            return
        weekly = clicked is weekly_btn

        filters = ";;".join(SUPPORTED_EXPORT_FORMATS.values())
        kind = "逐周课表" if weekly else "我的课程表"
        default_name = f"{kind}_{datetime.now():%Y%m%d_%H%M%S}.csv"
        file_path, _ = QFileDialog.getSaveFileName(
            self, "导出课程表", default_name, filters)
        if not file_path:
            return
        courses = list(self.selected.values())
        if weekly:
            ok, message = self.exporter.export_weekly(courses, file_path)
        else:
            ok, message = self.exporter.export(courses, file_path)
        if ok:
            QMessageBox.information(self, "导出成功", message)
        else:
            QMessageBox.critical(self, "导出失败", message)
