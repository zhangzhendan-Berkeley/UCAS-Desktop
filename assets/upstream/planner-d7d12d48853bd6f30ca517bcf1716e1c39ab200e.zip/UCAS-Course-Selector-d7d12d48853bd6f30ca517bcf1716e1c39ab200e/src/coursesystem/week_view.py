"""周视图组件：13 节 × 7 天课程表，周次导航与冲突高亮"""

import logging

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QHBoxLayout, QHeaderView, QLabel, QPushButton, QSpinBox,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .config import MAX_SLOT, MAX_WEEK, MIN_SLOT, MIN_WEEK, TIME_SLOTS, WEEKDAYS
from .conflict import is_in_week, parse_time_slots
from .models import Course

logger = logging.getLogger(__name__)

COLOR_NORMAL_BG = QColor("#d4edda")
COLOR_NORMAL_FG = QColor("#155724")
COLOR_CONFLICT_BG = QColor("#f8d7da")
COLOR_CONFLICT_FG = QColor("#721c24")


class WeekViewWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.courses: list[Course] = []
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # 周次导航栏
        nav = QHBoxLayout()
        self.prev_btn = QPushButton("上一周")
        self.next_btn = QPushButton("下一周")
        self.week_spin = QSpinBox()
        self.week_spin.setRange(MIN_WEEK, MAX_WEEK)
        self.week_spin.setValue(MIN_WEEK)
        self.week_spin.setFixedWidth(64)
        self.prev_btn.setFixedWidth(72)
        self.next_btn.setFixedWidth(72)
        self.week_label = QLabel(f"第 {MIN_WEEK} 周")
        self.week_label.setStyleSheet("font-weight: bold;")
        nav.addWidget(self.prev_btn)
        nav.addWidget(self.week_spin)
        nav.addWidget(self.next_btn)
        nav.addWidget(self.week_label)
        nav.addStretch()
        layout.addLayout(nav)

        # 课程表网格：行=节次，列=时间+周一~周日；行高随窗口均分充满
        self.table = QTableWidget(MAX_SLOT - MIN_SLOT + 1, 8)
        self.table.setHorizontalHeaderLabels(["时间"] + list(WEEKDAYS.values()))
        for slot in range(MIN_SLOT, MAX_SLOT + 1):
            time_text = TIME_SLOTS.get(slot, "")
            label = f"第{slot}节\n{time_text}" if time_text else f"第{slot}节"
            item = QTableWidgetItem(label)
            item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table.setItem(slot - MIN_SLOT, 0, item)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        layout.addWidget(self.table, stretch=1)

        # 底部统计栏
        self.stats_label = QLabel()
        legend = QLabel(
            '<span style="color:#16a34a">●</span> 正常课程 '
            '<span style="color:#dc2626">●</span> 时间冲突')
        for w in (self.stats_label, legend):
            w.setStyleSheet("color: #6b7280; font-size: 12px;")
        bottom = QHBoxLayout()
        bottom.addWidget(self.stats_label)
        bottom.addStretch()
        bottom.addWidget(legend)
        layout.addLayout(bottom)

        # 信号
        self.prev_btn.clicked.connect(
            lambda: self.week_spin.setValue(max(MIN_WEEK, self.week_spin.value() - 1)))
        self.next_btn.clicked.connect(
            lambda: self.week_spin.setValue(min(MAX_WEEK, self.week_spin.value() + 1)))
        self.week_spin.valueChanged.connect(self._refresh)

        self._refresh()

    def set_courses(self, courses: list[Course]):
        self.courses = courses
        self._refresh()

    def current_week(self) -> int:
        return self.week_spin.value()

    def _refresh(self):
        week = self.week_spin.value()
        self.week_label.setText(f"第 {week} 周")

        # 清空课程单元格（保留第 0 列时间表头）
        for row in range(self.table.rowCount()):
            for col in range(1, 8):
                self.table.setItem(row, col, None)

        # 构建 (day, slot) -> [(课程名, 地点), ...] 网格
        grid: dict[tuple[int, int], list[tuple[str, str]]] = {}
        active_courses: set[int] = set()
        for course in self.courses:
            for sched in course.schedules:
                if not (1 <= sched.day_of_week <= 7):
                    continue
                if not is_in_week(sched.weeks, week):
                    continue
                slots = parse_time_slots(sched.time_slots)
                for slot in slots:
                    if MIN_SLOT <= slot <= MAX_SLOT:
                        grid.setdefault((sched.day_of_week, slot), []).append(
                            (course.name, sched.location))
                        active_courses.add(course.id)

        conflict_cells = 0
        for (day, slot), entries in grid.items():
            text = "\n".join(
                f"{name}\n@{loc}" if loc else name for name, loc in entries)
            item = QTableWidgetItem(text)
            item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item.setToolTip(text)
            if len(entries) > 1:
                conflict_cells += 1
                item.setBackground(COLOR_CONFLICT_BG)
                item.setForeground(COLOR_CONFLICT_FG)
            else:
                item.setBackground(COLOR_NORMAL_BG)
                item.setForeground(COLOR_NORMAL_FG)
            self.table.setItem(slot - MIN_SLOT, day, item)

        self.stats_label.setText(
            f"第 {week} 周：{len(active_courses)} 门课程，{conflict_cells} 处时间冲突")
