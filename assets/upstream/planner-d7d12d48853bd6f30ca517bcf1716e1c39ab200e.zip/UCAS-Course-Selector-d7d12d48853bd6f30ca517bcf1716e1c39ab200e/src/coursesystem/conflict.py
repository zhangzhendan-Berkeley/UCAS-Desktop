"""时间解析与冲突检查

兼容的字符串格式（数据库与教务系统导出混用）：
- 枚举：'1、2'、'2、3、4'
- 区间：'1-16'、'5-6'
- 混排：'第2-5,7-18周'、'1-3,5-7'
"""

import re

from .models import Schedule

_TOKEN_SPLIT = re.compile(r"[,，、]")
_RANGE = re.compile(r"^(\d+)\s*-\s*(\d+)$")


def _parse_number_set(s: str) -> set[int]:
    """把枚举/区间/混排的数字字符串解析为整数集合"""
    if not s:
        return set()
    result: set[int] = set()
    for token in _TOKEN_SPLIT.split(s.strip("第周节 ")):
        token = token.strip()
        if not token:
            continue
        m = _RANGE.match(token)
        if m:
            result.update(range(int(m.group(1)), int(m.group(2)) + 1))
        elif token.isdigit():
            result.add(int(token))
    return result


def parse_time_slots(time_slots_str: str) -> set[int]:
    """解析节次字符串为节次集合，如 '1、2' -> {1, 2}，'10-12' -> {10, 11, 12}"""
    return _parse_number_set(time_slots_str)


def parse_weeks(weeks_str: str) -> set[int]:
    """解析周次字符串为周次集合，如 '1-16'、'2、3、4'、'第2-5,7-18周'"""
    return _parse_number_set(weeks_str)


def is_in_week(weeks_str: str, week: int) -> bool:
    """判断课程在某周是否上课（集合成员判断，避免子串误匹配）"""
    return week in parse_weeks(weeks_str)


def check_conflict(s1: Schedule, s2: Schedule) -> bool:
    """两条时间安排冲突 = 同星期 且 节次集合相交 且 周次集合相交"""
    if s1.day_of_week != s2.day_of_week:
        return False
    if not parse_time_slots(s1.time_slots) & parse_time_slots(s2.time_slots):
        return False
    return bool(parse_weeks(s1.weeks) & parse_weeks(s2.weeks))


def find_conflicts(new_schedules: list[Schedule],
                   existing: list[Schedule]) -> list[tuple[Schedule, Schedule]]:
    """返回新课程与已选课程之间所有冲突的时间安排对"""
    return [(n, e) for n in new_schedules for e in existing
            if check_conflict(n, e)]
