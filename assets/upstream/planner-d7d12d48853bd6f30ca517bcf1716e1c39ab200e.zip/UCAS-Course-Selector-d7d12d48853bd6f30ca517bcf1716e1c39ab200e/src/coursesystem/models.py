"""数据模型"""

from dataclasses import dataclass, field


@dataclass
class Course:
    id: int
    code: str
    name: str
    credits: str
    hours: str
    schedules: list["Schedule"] = field(default_factory=list)


@dataclass
class Schedule:
    course_id: int
    day_of_week: int  # 1=周一 ... 7=周日（DAO 层已从 TEXT 转为 int）
    time_slots: str   # 原始字符串，如 '1、2'
    location: str
    weeks: str        # 原始字符串，如 '2、3、4' 或 '1-16'
    semester: str
