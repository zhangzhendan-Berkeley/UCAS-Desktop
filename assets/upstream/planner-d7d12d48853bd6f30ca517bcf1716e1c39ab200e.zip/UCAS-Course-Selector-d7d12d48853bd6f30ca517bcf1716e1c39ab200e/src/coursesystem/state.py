"""应用状态持久化（JSON 文件）

缓存内容：
- db_path：当前使用的课程数据库（导入课表后记住新数据源）
- selected_course_ids：已选课程 id 列表（重启后恢复选课）
"""

import json
import logging

from .paths import data_dir

logger = logging.getLogger(__name__)

STATE_PATH = data_dir() / "app_state.json"


def load_state() -> dict:
    """读取状态文件，不存在或损坏时返回空状态"""
    try:
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("状态文件损坏，已忽略：%s", e)
        return {}


def save_state(*, db_path: str | None = None,
               selected_course_ids: list[int] | None = None,
               ui: dict | None = None):
    """合并写入状态（只更新传入的键；ui 字典按键级合并）"""
    state = load_state()
    if db_path is not None:
        state["db_path"] = db_path
    if selected_course_ids is not None:
        state["selected_course_ids"] = selected_course_ids
    if ui is not None:
        state["ui"] = {**state.get("ui", {}), **ui}
    try:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(
            json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as e:
        logger.warning("状态写入失败：%s", e)
