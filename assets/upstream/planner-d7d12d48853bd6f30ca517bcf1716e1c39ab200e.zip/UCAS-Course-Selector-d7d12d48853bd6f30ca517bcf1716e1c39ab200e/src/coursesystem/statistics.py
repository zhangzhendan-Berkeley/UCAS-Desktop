"""选课统计：横向单行状态条"""

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel

from .models import Course


class StatisticsWidget(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("statsBar")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 6, 12, 6)
        layout.setSpacing(0)
        self.credits_label = QLabel()
        self.count_label = QLabel()
        self.conflict_label = QLabel()
        sep1 = QLabel("·")
        sep2 = QLabel("·")
        for sep in (sep1, sep2):
            sep.setStyleSheet("color: #9ca3af; padding: 0 10px;")
        layout.addWidget(self.credits_label)
        layout.addWidget(sep1)
        layout.addWidget(self.count_label)
        layout.addWidget(sep2)
        layout.addWidget(self.conflict_label)
        layout.addStretch()
        self.setFixedHeight(36)
        self.update_stats([], 0)

    def update_stats(self, courses: list[Course], conflict_count: int):
        total_credits = 0.0
        for course in courses:
            try:
                total_credits += float(course.credits)
            except (TypeError, ValueError):
                pass
        self.credits_label.setText(f"已选学分 <b>{total_credits:g}</b>")
        self.count_label.setText(f"已选课程 <b>{len(courses)}</b> 门")
        color = "#dc2626" if conflict_count else "#16a34a"
        self.conflict_label.setText(
            f'时间冲突 <b style="color:{color}">{conflict_count}</b> 处')
