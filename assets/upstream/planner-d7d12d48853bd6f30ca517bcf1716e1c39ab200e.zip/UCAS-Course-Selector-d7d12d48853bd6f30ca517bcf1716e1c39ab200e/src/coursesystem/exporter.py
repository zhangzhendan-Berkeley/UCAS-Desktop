"""课程表导出：明细列表 / 逐周课表 × CSV / Excel / PDF / JSON"""

import csv
import json
import logging
from datetime import datetime
from pathlib import Path

from .config import MAX_SLOT, MIN_SLOT, TIME_SLOTS, WEEKDAYS
from .conflict import is_in_week, parse_time_slots, parse_weeks
from .models import Course

logger = logging.getLogger(__name__)

HEADERS = ["课程代码", "课程名称", "学分", "学时", "星期", "时间", "地点", "周次", "学期"]


def _flatten(courses: list[Course]) -> list[list[str]]:
    """把课程按时间安排展开为行，一节次范围合并显示"""
    rows = []
    for c in courses:
        if not c.schedules:
            rows.append([c.code, c.name, c.credits, c.hours, "", "", "", "", ""])
            continue
        for s in c.schedules:
            weekday = WEEKDAYS.get(s.day_of_week, f"第{s.day_of_week}天")
            slots = sorted(parse_time_slots(s.time_slots))
            if slots:
                span = f"第{slots[0]}-{slots[-1]}节" if len(slots) > 1 else f"第{slots[0]}节"
                start = TIME_SLOTS.get(slots[0], "").split("-")[0]
                end = TIME_SLOTS.get(slots[-1], "").split("-")[-1]
                time_text = f"{span} {start}-{end}" if start and end else span
            else:
                time_text = s.time_slots
            rows.append([c.code, c.name, c.credits, c.hours,
                         weekday, time_text, s.location, s.weeks, s.semester])
    return rows


class ScheduleExporter:
    """按文件扩展名分发导出，返回 (是否成功, 提示信息)"""

    def export(self, courses: list[Course], file_path: str | Path) -> tuple[bool, str]:
        path = Path(file_path)
        suffix = path.suffix.lower()
        try:
            if suffix == ".csv":
                self._to_csv(courses, path)
            elif suffix == ".xlsx":
                self._to_excel(courses, path)
            elif suffix == ".pdf":
                self._to_pdf(courses, path)
            elif suffix == ".json":
                self._to_json(courses, path)
            else:
                return False, f"不支持的导出格式：{suffix}"
        except Exception as e:
            logger.exception("导出失败")
            return False, f"导出失败：{e}"
        return True, f"课程表已导出到：{path}"

    def _to_csv(self, courses: list[Course], path: Path):
        # utf-8-sig 保证 Excel 打开中文不乱码
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(HEADERS)
            writer.writerows(_flatten(courses))

    def _to_excel(self, courses: list[Course], path: Path):
        import pandas as pd
        pd.DataFrame(_flatten(courses), columns=HEADERS).to_excel(
            path, sheet_name="课程表", index=False)

    def _to_json(self, courses: list[Course], path: Path):
        data = {
            "export_time": datetime.now().isoformat(),
            "courses": [
                {
                    "code": c.code, "name": c.name,
                    "credits": c.credits, "hours": c.hours,
                    "schedules": [
                        {
                            "day_of_week": s.day_of_week,
                            "weekday": WEEKDAYS.get(s.day_of_week, ""),
                            "time_slots": s.time_slots,
                            "location": s.location,
                            "weeks": s.weeks,
                            "semester": s.semester,
                        }
                        for s in c.schedules
                    ],
                }
                for c in courses
            ],
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _to_pdf(self, courses: list[Course], path: Path):
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))

        doc = SimpleDocTemplate(str(path), pagesize=landscape(A4))
        title_style = ParagraphStyle(
            "title", fontName="STSong-Light", fontSize=18, alignment=1)
        cell_style = ParagraphStyle(
            "cell", fontName="STSong-Light", fontSize=9, alignment=1, leading=12)

        elements = [Paragraph("课程表", title_style), Spacer(1, 8 * mm)]
        table_data = [[Paragraph(h, cell_style) for h in HEADERS[:-1]]]
        for row in _flatten(courses):
            table_data.append([Paragraph(str(cell), cell_style) for cell in row[:-1]])

        table = Table(table_data, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0366d6")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1),
             [colors.white, colors.HexColor("#f6f8fa")]),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e1e4e8")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        elements.append(table)
        doc.build(elements)

    # ---------- 逐周课表 ----------

    def export_weekly(self, courses: list[Course], file_path: str | Path) -> tuple[bool, str]:
        """按周次导出网格课表（每周一张 13 节 × 7 天的表）"""
        path = Path(file_path)
        suffix = path.suffix.lower()
        grids = _weekly_grids(courses)
        if not grids:
            return False, "所选课程没有任何周次安排"
        try:
            if suffix == ".csv":
                self._weekly_to_csv(grids, path)
            elif suffix == ".xlsx":
                self._weekly_to_excel(grids, path)
            elif suffix == ".pdf":
                self._weekly_to_pdf(grids, path)
            elif suffix == ".json":
                self._weekly_to_json(grids, path)
            else:
                return False, f"不支持的导出格式：{suffix}"
        except Exception as e:
            logger.exception("导出失败")
            return False, f"导出失败：{e}"
        return True, f"逐周课表已导出到：{path}（共 {len(grids)} 周）"

    def _weekly_to_csv(self, grids: dict[int, list[list[str]]], path: Path):
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            for week, rows in grids.items():
                writer.writerow([f"第{week}周"])
                writer.writerows(rows)
                writer.writerow([])

    def _weekly_to_excel(self, grids: dict[int, list[list[str]]], path: Path):
        import pandas as pd
        with pd.ExcelWriter(path) as writer:
            for week, rows in grids.items():
                pd.DataFrame(rows[1:], columns=rows[0]).to_excel(
                    writer, sheet_name=f"第{week}周", index=False)

    def _weekly_to_json(self, grids: dict[int, list[list[str]]], path: Path):
        data = {
            "export_time": datetime.now().isoformat(),
            "format": "weekly_grid",
            "weeks": {
                str(week): {
                    "header": rows[0],
                    "rows": rows[1:],
                }
                for week, rows in grids.items()
            },
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _weekly_to_pdf(self, grids: dict[int, list[list[str]]], path: Path):
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        from reportlab.platypus import (
            PageBreak, Paragraph, SimpleDocTemplate, Table, TableStyle,
        )

        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
        doc = SimpleDocTemplate(str(path), pagesize=landscape(A4))
        title_style = ParagraphStyle(
            "title", fontName="STSong-Light", fontSize=16, alignment=1)
        cell_style = ParagraphStyle(
            "cell", fontName="STSong-Light", fontSize=8, alignment=1, leading=11)

        elements = []
        for i, (week, rows) in enumerate(grids.items()):
            if i:
                elements.append(PageBreak())
            elements.append(Paragraph(f"第 {week} 周课程表", title_style))
            table_data = [[Paragraph(str(cell), cell_style) for cell in row]
                          for row in rows]
            table = Table(table_data, repeatRows=1)
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0366d6")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e1e4e8")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]))
            elements.append(table)
        doc.build(elements)


def _weekly_grids(courses: list[Course]) -> dict[int, list[list[str]]]:
    """生成逐周网格：{周次: 矩阵}（矩阵首行为表头：时间/周一…周日）

    只包含有课程安排的周次；同一单元格多门课用 ' | ' 连接。
    """
    active_weeks: set[int] = set()
    for c in courses:
        for s in c.schedules:
            active_weeks |= parse_weeks(s.weeks)

    grids: dict[int, list[list[str]]] = {}
    for week in sorted(active_weeks):
        # (day, slot) -> [课程名@地点, ...]
        grid: dict[tuple[int, int], list[str]] = {}
        for c in courses:
            for s in c.schedules:
                if not (1 <= s.day_of_week <= 7) or not is_in_week(s.weeks, week):
                    continue
                text = f"{c.name}@{s.location}" if s.location else c.name
                for slot in parse_time_slots(s.time_slots):
                    if MIN_SLOT <= slot <= MAX_SLOT:
                        grid.setdefault((s.day_of_week, slot), []).append(text)

        header = ["时间"] + list(WEEKDAYS.values())
        rows = [header]
        for slot in range(MIN_SLOT, MAX_SLOT + 1):
            time_text = TIME_SLOTS.get(slot, "")
            row = [f"第{slot}节\n{time_text}" if time_text else f"第{slot}节"]
            row += [" | ".join(grid.get((day, slot), [])) for day in range(1, 8)]
            rows.append(row)
        grids[week] = rows
    return grids
