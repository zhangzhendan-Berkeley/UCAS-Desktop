"""运行时路径解析（开发态 / PyInstaller 冻结态统一）"""

import sys
from pathlib import Path


def data_dir() -> Path:
    """用户数据目录（状态缓存、导入生成的课程库）

    冻结态（PyInstaller）：exe 同级 data/，便携可写
    开发态：项目根目录 data/
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "data"
    return Path(__file__).resolve().parents[2] / "data"
