"""课程数据库访问层"""

import logging
import sqlite3
from pathlib import Path

from .config import DATABASE_PATH
from .models import Course, Schedule

logger = logging.getLogger(__name__)


class CourseDatabase:
    def __init__(self, db_path: Path = DATABASE_PATH):
        self.db_path = str(db_path)
        self.is_valid = self._check_valid()
        self.has_department = False
        self.has_attribute = False
        if self.is_valid:
            columns = {r[1] for r in self._query("PRAGMA table_info(courses)")}
            self.has_department = "department" in columns
            self.has_attribute = "attribute" in columns
        else:
            logger.warning("课程库无效或不存在，进入空态：%s", self.db_path)

    def _check_valid(self) -> bool:
        """库文件存在且含 courses 表才视为有效（避免 connect 创建空文件后查询崩溃）"""
        if not Path(self.db_path).is_file():
            return False
        try:
            rows = self._query(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='courses'")
            return bool(rows)
        except sqlite3.Error:
            return False

    def _query(self, sql: str, params: tuple = ()) -> list[tuple]:
        conn = sqlite3.connect(self.db_path)
        try:
            return conn.execute(sql, params).fetchall()
        finally:
            conn.close()

    @staticmethod
    def _to_course(row: tuple) -> Course:
        cid, name, credits, hours, code = row
        return Course(id=cid, code=code or "", name=name or "",
                      credits=credits or "", hours=hours or "")

    @staticmethod
    def _to_schedule(row: tuple) -> Schedule:
        course_id, day, slots, location, weeks, semester = row
        return Schedule(
            course_id=course_id,
            day_of_week=int(day),
            time_slots=slots or "",
            location=location or "",
            weeks=weeks or "",
            semester=semester or "",
        )

    def get_all_courses(self) -> list[Course]:
        if not self.is_valid:
            return []
        rows = self._query(
            "SELECT DISTINCT c.id, c.course_name, c.credits, c.hours, c.course_code "
            "FROM courses c ORDER BY c.course_name"
        )
        return [self._to_course(r) for r in rows]

    def search_courses(self, keyword: str = "", department: str | None = None,
                       level: str | None = None, campus: str | None = None,
                       unit: str | None = None, menlei: str | None = None,
                       category: str | None = None, field: str | None = None,
                       attribute: str | None = None) -> list[Course]:
        """组合筛选：关键词模糊 + 院系/属性等值 + 编码位筛选（层次/校区/开课单位/学科归属）"""
        if not self.is_valid:
            return []
        sql = (
            "SELECT DISTINCT c.id, c.course_name, c.credits, c.hours, c.course_code "
            "FROM courses c WHERE 1=1"
        )
        params: list[str] = []
        if keyword:
            sql += " AND (c.course_name LIKE ? OR c.course_code LIKE ?)"
            params += [f"%{keyword}%", f"%{keyword}%"]
        if department and self.has_department:
            sql += " AND c.department = ?"
            params.append(department)
        if attribute and self.has_attribute:
            sql += " AND c.attribute = ?"
            params.append(attribute)
        if level:
            sql += " AND substr(c.course_code, 13, 1) = ?"
            params.append(level)
        if campus:
            sql += " AND substr(c.course_code, 18, 1) = ?"
            params.append(campus)
        if unit:
            sql += " AND substr(c.course_code, 1, 1) = ?"
            params.append(unit)
        if field:
            # 专业领域：6 位学科代码精确匹配（优先级高于类别/门类）
            sql += " AND substr(c.course_code, 7, 6) = ?"
            params.append(field)
        elif category:
            # 学科归属：6 位学科代码的前 4 位（自设码如 '0705Z1' 同样命中）
            sql += " AND substr(c.course_code, 7, 4) = ?"
            params.append(category)
        elif menlei:
            # 学科门类：前 2 位
            sql += " AND substr(c.course_code, 7, 2) = ?"
            params.append(menlei)
        sql += " ORDER BY c.course_name"
        return [self._to_course(r) for r in self._query(sql, tuple(params))]

    def get_departments(self) -> list[str]:
        """院系去重列表（无 department 列的旧库返回空）"""
        if not self.is_valid or not self.has_department:
            return []
        rows = self._query(
            "SELECT DISTINCT department FROM courses "
            "WHERE department IS NOT NULL AND department != '' ORDER BY department"
        )
        return [r[0] for r in rows]

    def get_attributes(self) -> list[str]:
        """课程属性去重列表（无 attribute 列的旧库返回空）"""
        if not self.is_valid or not self.has_attribute:
            return []
        rows = self._query(
            "SELECT DISTINCT attribute FROM courses "
            "WHERE attribute IS NOT NULL AND attribute != '' ORDER BY attribute"
        )
        return [r[0] for r in rows]

    def get_categories(self) -> list[str]:
        """库中实际出现的学科类别（学科代码前 4 位）去重列表"""
        if not self.is_valid:
            return []
        rows = self._query(
            "SELECT DISTINCT substr(course_code, 7, 4) FROM courses "
            "WHERE substr(course_code, 7, 4) GLOB '[0-9][0-9][0-9][0-9]' "
            "ORDER BY 1"
        )
        return [r[0] for r in rows]

    def get_fields(self, category: str) -> list[str]:
        """某类别下库中实际出现的 6 位学科代码（含 '0705Z1' 类自设码）"""
        if not self.is_valid:
            return []
        rows = self._query(
            "SELECT DISTINCT substr(course_code, 7, 6) FROM courses "
            "WHERE substr(course_code, 7, 4) = ? ORDER BY 1",
            (category,),
        )
        return [r[0] for r in rows]

    def get_course_schedules(self, course_id: int) -> list[Schedule]:
        if not self.is_valid:
            return []
        rows = self._query(
            "SELECT course_id, day_of_week, time_slots, location, weeks, semester "
            "FROM course_schedules WHERE course_id = ?",
            (course_id,),
        )
        return [self._to_schedule(r) for r in rows]

    def get_courses_with_schedules(self, course_ids: list[int]) -> list[Course]:
        """取多门课程及其全部时间安排（导出用）"""
        if not course_ids or not self.is_valid:
            return []
        placeholders = ",".join("?" for _ in course_ids)
        rows = self._query(
            "SELECT c.id, c.course_name, c.credits, c.hours, c.course_code, "
            "cs.day_of_week, cs.time_slots, cs.location, cs.weeks, cs.semester "
            "FROM courses c "
            "LEFT JOIN course_schedules cs ON c.id = cs.course_id "
            f"WHERE c.id IN ({placeholders}) "
            "ORDER BY c.course_name, cs.day_of_week, cs.time_slots",
            tuple(course_ids),
        )
        courses: dict[int, Course] = {}
        for cid, name, credits, hours, code, day, slots, location, weeks, semester in rows:
            course = courses.setdefault(cid, self._to_course((cid, name, credits, hours, code)))
            if day is not None:
                course.schedules.append(self._to_schedule(
                    (cid, day, slots, location, weeks, semester)))
        return list(courses.values())
