"""UCAS 课程选择模拟器（PySide6 版）"""

import logging
import sys

__version__ = "3.0.0"

logger = logging.getLogger(__name__)


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        print("缺少依赖 PySide6，请先运行: uv sync")
        sys.exit(1)

    from .config import APP_NAME, APP_VERSION
    from .main_window import MainWindow

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)

    window = MainWindow()
    window.show()
    logger.info("应用启动成功")
    sys.exit(app.exec())
