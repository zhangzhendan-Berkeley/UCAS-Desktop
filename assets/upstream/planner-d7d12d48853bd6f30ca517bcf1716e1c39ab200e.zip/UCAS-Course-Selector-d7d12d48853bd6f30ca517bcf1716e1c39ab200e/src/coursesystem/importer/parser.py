"""教务系统课表 Excel 解析

输入：教务系统直接导出的 xlsx（表头：序号/开课院系/课程编码/课程名称/英文名称/
课程属性/培养层次/所属学科/课时学分/限选人数/已选人数/开课周/星期节次/教室/…）。
结构特点：一门课程占多行（合并单元格），首行含课程信息，后续行只有
开课周/星期节次/教室等时间安排列有值。
"""

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# 列索引（与导出表头一一对应）
COL_SERIAL = 0    # 序号（仅课程首行有值）
COL_DEPT = 1      # 开课院系
COL_CODE = 2      # 课程编码
COL_NAME = 3      # 课程名称
COL_ATTR = 5      # 课程属性（学科核心课/公共选修课等）
COL_HOURS_CREDITS = 8   # 课时/学分，如 "60/3.0"
COL_WEEKS = 11    # 开课周，如 "第2-5,7-18周"
COL_DAY_SLOTS = 12  # 星期节次，如 "周二(5-6)"、"周六(1-3,5-7)"
COL_LOCATION = 13  # 教室
COL_TEACHER = 18  # 主讲教师

_WEEKDAY = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "日": 7}
_DAY_SLOTS_RE = re.compile(r"^周([一二三四五六日])\(([\d,\-、，]+)\)$")
_SEMESTER_RE = re.compile(r"(\d{4})\s*年?\s*(春|秋)")


@dataclass
class ParsedSchedule:
    day_of_week: int
    time_slots: str  # 规范化为顿号枚举，如 "5、6"
    location: str
    weeks: str       # 保留原始可读字符串，如 "第2-5,7-18周"


@dataclass
class ParsedCourse:
    code: str
    name: str
    credits: str
    hours: str
    department: str = ""
    teacher: str = ""
    attribute: str = ""  # 课程属性：学科核心课/公共选修课等
    schedules: list[ParsedSchedule] = field(default_factory=list)


@dataclass
class ParseResult:
    courses: list[ParsedCourse]
    semester: str          # 从文件名推断，如 "2026秋季"
    skipped_rows: int = 0  # 无法解析的时间安排行数


def _expand_slots(slots_str: str) -> str:
    """'5-6' / '1-3,5-7' -> '5、6' / '1、2、3、5、6、7'（与既有数据库格式一致）"""
    from ..conflict import parse_time_slots
    return "、".join(str(s) for s in sorted(parse_time_slots(slots_str)))


def parse_xlsx(path: str | Path) -> ParseResult:
    import openpyxl

    path = Path(path)
    m = _SEMESTER_RE.search(path.stem)
    semester = f"{m.group(1)}{m.group(2)}" if m else "未指定"

    wb = openpyxl.load_workbook(path)
    ws = wb[wb.sheetnames[0]]

    courses: list[ParsedCourse] = []
    current: ParsedCourse | None = None
    last_location = ""  # 教室列存在合并单元格，续行为空时继承上一行
    skipped = 0

    for row in ws.iter_rows(min_row=2, values_only=True):
        vals = ["" if v is None else str(v).strip() for v in row]
        if vals[COL_SERIAL]:  # 新课程的首行
            hours, _, credits = vals[COL_HOURS_CREDITS].partition("/")
            current = ParsedCourse(
                code=vals[COL_CODE],
                name=vals[COL_NAME],
                credits=credits.strip(),
                hours=hours.strip(),
                department=vals[COL_DEPT],
                teacher=vals[COL_TEACHER],
                attribute=vals[COL_ATTR],
            )
            courses.append(current)
            last_location = ""

        if current is None:
            continue  # 表头与首门课之间的空行

        weeks_str = vals[COL_WEEKS]
        day_slots = vals[COL_DAY_SLOTS]
        if not weeks_str and not day_slots:
            continue
        m = _DAY_SLOTS_RE.match(day_slots)
        if not m or not weeks_str:
            skipped += 1
            logger.warning("跳过无法解析的行: 开课周=%r 星期节次=%r", weeks_str, day_slots)
            continue
        if vals[COL_LOCATION]:
            last_location = vals[COL_LOCATION]
        current.schedules.append(ParsedSchedule(
            day_of_week=_WEEKDAY[m.group(1)],
            time_slots=_expand_slots(m.group(2)),
            location=last_location,
            weeks=weeks_str,
        ))

    return ParseResult(courses=courses, semester=semester, skipped_rows=skipped)
