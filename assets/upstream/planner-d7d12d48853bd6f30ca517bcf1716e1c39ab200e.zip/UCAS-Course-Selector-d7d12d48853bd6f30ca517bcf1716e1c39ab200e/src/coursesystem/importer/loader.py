"""解析结果写入 SQLite

生成的数据库与参考项目同构（courses / course_schedules 两表），
courses 表额外保留 department、teacher 两列供后续使用。
"""

import sqlite3
from pathlib import Path

from .parser import ParseResult

_SCHEMA = """
CREATE TABLE courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT,
    course_name TEXT,
    credits TEXT,
    hours TEXT,
    department TEXT,
    teacher TEXT,
    attribute TEXT
);
CREATE TABLE course_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER,
    day_of_week TEXT,
    time_slots TEXT,
    location TEXT,
    weeks TEXT,
    semester TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_schedules_course ON course_schedules(course_id);
"""


def write_db(result: ParseResult, db_path: str | Path) -> tuple[int, int]:
    """把解析结果写入新的 SQLite 库（已存在则覆盖），返回 (课程数, 时间安排数)"""
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    if db_path.exists():
        db_path.unlink()

    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(_SCHEMA)
        schedule_count = 0
        for c in result.courses:
            cur = conn.execute(
                "INSERT INTO courses (course_code, course_name, credits, hours, "
                "department, teacher, attribute) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (c.code, c.name, c.credits, c.hours, c.department, c.teacher,
                 c.attribute),
            )
            course_id = cur.lastrowid
            for s in c.schedules:
                conn.execute(
                    "INSERT INTO course_schedules "
                    "(course_id, day_of_week, time_slots, location, weeks, semester) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (course_id, str(s.day_of_week), s.time_slots,
                     s.location, s.weeks, result.semester),
                )
                schedule_count += 1
        conn.commit()
    finally:
        conn.close()
    return len(result.courses), schedule_count
