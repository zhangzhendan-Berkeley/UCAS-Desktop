"""PyInstaller 打包入口（绝对导入；__main__.py 的相对导入不能直接作入口脚本）"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from coursesystem import main

if __name__ == "__main__":
    main()
